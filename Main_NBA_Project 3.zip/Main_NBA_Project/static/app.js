// url = ``
d3.json('/stats/TOR').then(function(data){
  console.log(data)
})



// LEAFLET.JS MAP 
var mymap = L.map('mapid').setView([51.505, -0.09], 2);
L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
maxZoom: 14,
id: 'mapbox.streets',
accessToken: 'pk.eyJ1Ijoic2hhdW5tYWNsZWxsYW4iLCJhIjoiY2p3M204cWtlMGJ5dDN6cnkxdnJtNXRwOCJ9.JmUF1dhDfzF-PFQShivk-w'
}).addTo(mymap);

    // Creating Basketball Icon
    var BasketballIcon = L.Icon.extend({
    options: {
        iconSize:     [38, 95],
        iconAnchor:   [22, 94],
        popupAnchor:  [-3, -76]
    }
    });

    // Basketball Icon 
    var basketball_icon_img = new BasketballIcon({iconUrl: 'basketballicon.png'})
    L.icon = function (options) {
    return new L.Icon(options);
    };

     //Marker for each player's country with Basketball Icon
    L.marker([51.5, -0.09], {icon: basketball_icon_img}).addTo(mymap);



// PLOTLY CHART FOR PLAYER EFFICIENCY RATING 
              var data = [
  {
      x: ['Kawhi Leonard', 'Jonas Valanciunas', 'Chris Boucher', 'Serge Ibaka', 'Pascal Siakam', 'Kyle Lowry', 'Jordan Loyd' ],
      y: [25.89, 24.47, 22.28, 18.80, 18.74, 16.51, 16.36 ],
      type: 'bar'
  }
  ];
  var layout = {
  title: 'Player Efficiency Rating Per Player',
  font:{
      family: 'Raleway, sans-serif'
  },
  showlegend: false,
  xaxis: {
      tickangle: -45
  },
  yaxis: {
      title: 'Player Efficiency Rating',
      zeroline: false,
      gridwidth: 2
  },
  bargap :0.05
  };
  Plotly.newPlot('PER_graph', data, layout);


// PLOTLY CHART FOR POINTS AND ASSISTS

  var trace1 = {
  x: ['Kawhi Leonard', 'Jonas Valanciunas', 'Chris Boucher'],
  y: [26.6, 12.8, 3.3],
  name: 'Points',
  type: 'bar'
  };

  var trace2 = {
  x: ['Kawhi Leonard', 'Jonas Valanciunas', 'Chris Boucher'],
  y: [3.3, 1.0, 0.1],
  name: 'Assists',
  type: 'bar'
  };

  // MY ATTEMPT ON PARSING
  var jsondata = {};
    
  //Team Year Roster Table
  console.log(data.team["TOR"].Year["2019"].Name);
  console.log(data.team["TOR"].Year["2019"].Pos);
  console.log(data.team["TOR"].Year["2019"].Height);
  console.log(data.team["TOR"].Year["2019"].Weight);

  //Team Player Efficiency Rating for Plotly Graph (haven't pulled PlayerEfficiencyRating)
  console.log(data.team["TOR"].Year["2019"].Name)
  console.log(data.team["TOR"].Year["2019"].PER)

  //Team Points/Assist Per Game for Plotly Graph (haven't pulled PlayerEfficiencyRating)
  console.log(data.team["TOR"].Year["2019"].Name)
  console.log(data.team["TOR"].Year["2019"].PointsPerGame)
  console.log(data.team["TOR"].Year["2019"].Assists)
  
  

  // Chart for Name X Player Efficiency Rating
  PERtrace = {
    "x": Name,
    "y": PER,
    "type": "bar"
}

   // Chart for Name X Player Efficiency Rating
   PointsTraceZ = {
    "x": Name,
    "y": PER,
    "type": "bar"
}


  var data = [trace1, trace2];

  var layout = {
  title: "Players Points and Assist Comparison per Game ",
  barmode: 'group' 
  };

  Plotly.newPlot('Points_graph', data, layout)


// PULL INFO FROM API URL ROUTE
// PUT INTO HTML TABLE 
 
//  var defaultURL = `/api/get_team`;
//  d3.json(defaultURL).then(function(error,data) {
//    alert(data);
//   d3.select("tbody")
//   .selectAll("tr")
//   .data(data)
//   .enter()
//   .append("tr")
//   .html(function(d) {
//     return `<td>${d.Name}</td><td>${d.Pos}</td><td>${d.Height}</td><td>${d.Weight}</td><td>${d.Year}</td><td>${d.Team}</td>`;
//   });
//  });





