 var defaultURL = `/api/get_team`;
 d3.json(defaultURL).then(function(data) {
   //console.log(data)
  d3.select("tbody")
  .selectAll("tr")
  .data(data)
  .enter()
  .append("tr")
  .html(function(d) {
    return `<td>${d.Year}</td><td>${d.Team}</td>`;
  });
  });




// var data = [data];
 // var layout = { margin: { t: 30, b: 100 } };
 // Plotly.plot("bar", data, layout);