select Points_Season from updatedmastertable;
